@echo off
nodknaKra_renderer_oop.exe standard 42
pause
